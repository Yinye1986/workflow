#!/data/data/com.termux/files/usr/bin/bash

git add .
git commit -m "Sync"
git push origin main
